import tkinter as tk
from tkinter import ttk, messagebox
import math
import time

# --- Classe Bola ---
class Bola:
    def __init__(self, canvas, x, y, raio, cor, tipo, nome, massa=1.0, vx=0.0, vy=0.0):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.raio = raio
        self.cor = cor
        self.tipo = tipo  # 'solida', 'listrada', 'bola_8', 'bola_branca'
        self.nome = nome
        self.massa = massa
        self.vx = vx
        self.vy = vy
        self.id = None  
        self.id_faixa = None 
        self.id_sombra = None
        self.ativa = True 
        self.desenhar()

    def desenhar(self):
        if self.id:
            self.canvas.delete(self.id)
            if self.id_faixa: self.canvas.delete(self.id_faixa)
            if self.id_sombra: self.canvas.delete(self.id_sombra)

        self.id_sombra = self.canvas.create_oval(
            self.x - self.raio + 2, self.y - self.raio + 2,
            self.x + self.raio + 2, self.y + self.raio + 2,
            fill='#002200', outline=''
        )

        self.id = self.canvas.create_oval(
            self.x - self.raio, self.y - self.raio,
            self.x + self.raio, self.y + self.raio,
            fill=self.cor, outline='black', width=1
        )
        
        if self.tipo == 'listrada':
            self.id_faixa = self.canvas.create_line(
                self.x - self.raio, self.y, self.x + self.raio, self.y,
                fill='white', width=self.raio / 1.5
            )

    def atualizar_posicao(self, dt):
        if not self.ativa: return
        self.x += self.vx * dt
        self.y += self.vy * dt
        
        self.canvas.coords(
            self.id,
            self.x - self.raio, self.y - self.raio,
            self.x + self.raio, self.y + self.raio
        )
        self.canvas.coords(
            self.id_sombra,
            self.x - self.raio + 2, self.y - self.raio + 2,
            self.x + self.raio + 2, self.y + self.raio + 2
        )
        if self.tipo == 'listrada' and self.id_faixa:
            self.canvas.coords(
                self.id_faixa,
                self.x - self.raio, self.y, self.x + self.raio, self.y
            )

    def aplicar_atrito(self, dt, desaceleracao_linear=150.0):
        """
        Aplica um atrito linear realista. 
        A velocidade diminui por um valor constante por segundo (a = F/m).
        """
        if not self.ativa: return
        v = math.sqrt(self.vx**2 + self.vy**2)
        if v > 1.0:
            # Redução de velocidade linear: v_new = v_old - a*dt
            nova_v = max(0, v - desaceleracao_linear * dt)
            fator = nova_v / v
            self.vx *= fator
            self.vy *= fator
        else:
            self.vx = 0.0
            self.vy = 0.0

    def remover(self):
        self.ativa = False
        self.canvas.delete(self.id)
        self.canvas.delete(self.id_sombra)
        if self.id_faixa:
            self.canvas.delete(self.id_faixa)

# --- Funções de Física ---
def resolver_colisao_bolas(bola1, bola2, e=0.95):
    """
    Resolve a colisão entre duas bolas usando conservação de momento e 
    coeficiente de restituição (e).
    """
    if not bola1.ativa or not bola2.ativa: return False
    
    dx = bola2.x - bola1.x
    dy = bola2.y - bola1.y
    distancia_sq = dx**2 + dy**2
    raio_soma = bola1.raio + bola2.raio
    
    if distancia_sq <= raio_soma**2:
        distancia = math.sqrt(distancia_sq)
        if distancia == 0: distancia = 0.1 # Evitar divisão por zero
        
        # Vetor normal unitário
        nx = dx / distancia
        ny = dy / distancia
        
        # Velocidade relativa
        rvx = bola2.vx - bola1.vx
        rvy = bola2.vy - bola1.vy
        
        # Velocidade relativa na direção normal
        vel_normal = rvx * nx + rvy * ny
        
        # Se as bolas já estão se afastando, não faz nada
        if vel_normal > 0: return False
        
        # Impulso escalar
        m1, m2 = bola1.massa, bola2.massa
        j = -(1 + e) * vel_normal
        j /= (1/m1 + 1/m2)
        
        # Aplicar impulso
        impulso_x = j * nx
        impulso_y = j * ny
        
        bola1.vx -= (1/m1) * impulso_x
        bola1.vy -= (1/m1) * impulso_y
        bola2.vx += (1/m2) * impulso_x
        bola2.vy += (1/m2) * impulso_y
        
        # Correção de sobreposição (Positional Correction)
        # Previne que as bolas fiquem presas uma na outra
        percent = 0.5 # Quão agressiva é a correção (0.2 a 0.8)
        slop = 0.01   # Tolerância
        overlap = max(0.0, raio_soma - distancia - slop)
        correcao = overlap / (1/m1 + 1/m2) * percent
        
        bola1.x -= (1/m1) * correcao * nx
        bola1.y -= (1/m1) * correcao * ny
        bola2.x += (1/m2) * correcao * nx
        bola2.y += (1/m2) * correcao * ny
        
        return True
    return False

def resolver_colisao_paredes(bola, x_min, y_min, x_max, y_max, e_parede=0.8):
    """
    Resolve a colisão com as bordas da mesa.
    """
    if not bola.ativa: return
    
    colidiu = False
    if bola.x - bola.raio < x_min:
        bola.x = x_min + bola.raio
        bola.vx *= -e_parede
        colidiu = True
    elif bola.x + bola.raio > x_max:
        bola.x = x_max - bola.raio
        bola.vx *= -e_parede
        colidiu = True

    if bola.y - bola.raio < y_min:
        bola.y = y_min + bola.raio
        bola.vy *= -e_parede
        colidiu = True
    elif bola.y + bola.raio > y_max:
        bola.y = y_max - bola.raio
        bola.vy *= -e_parede
        colidiu = True
    return colidiu

# --- Classe Principal do Jogo ---
class BilharApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Elite 8 Ball Pool - Physics Pro")
        self.root.geometry("1200x800")
        self.root.configure(bg="#0f0f0f")
        
        # Estado do Jogo
        self.jogador_atual = 1
        self.grupos_definidos = False
        self.grupos = {1: None, 2: None}
        self.bolas_encacapadas_nesta_jogada = []
        self.primeira_bola_atingida = None
        self.movendo = False
        self.vencedor = None
        self.bola_na_mao = False
        self.selecionada = False
        self.branca = None
        self.bolas = []
        self.mass_vars = {}
        self.mira_id = None
        self.trajetoria_id = None
        
        # Indicadores de Velocidade
        self.vel_branca_saida = 0.0
        self.vel_alvo_impacto = 0.0
        self.ja_registrou_impacto = False
        
        # Variável para Coeficiente de Restituição e Atrito
        self.coef_restituicao = tk.DoubleVar(value=0.95)
        self.coef_atrito = tk.DoubleVar(value=150.0)
        
        # Configurações da Mesa
        self.mesa_w = 800
        self.mesa_h = 400
        self.margin_x = 100
        self.margin_y = 150
        self.buraco_r = 28
        self.espessura_moldura = 40
        
        self.mostrar_tela_inicial()

    def mostrar_tela_inicial(self):
        self.clear_screen()
        self.start_frame = tk.Frame(self.root, bg="#0f0f0f")
        self.start_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        tk.Label(self.start_frame, text="ELITE", font=("Impact", 40), fg="#FFD700", bg="#0f0f0f").pack()
        tk.Label(self.start_frame, text="8 BALL POOL", font=("Impact", 80), fg="white", bg="#0f0f0f").pack()
        tk.Label(self.start_frame, text="GRUPO 1", font=("Helvetica", 14, "italic"), fg="#888", bg="#0f0f0f").pack(pady=(0, 40))
        tk.Button(self.start_frame, text="JOGAR AGORA", font=("Helvetica", 16, "bold"), bg="#2ecc71", fg="white", width=20, bd=0, cursor="hand2", command=self.iniciar_jogo).pack(pady=10)
        tk.Button(self.start_frame, text="SAIR", font=("Helvetica", 14, "bold"), bg="#e74c3c", fg="white", width=20, bd=0, cursor="hand2", command=self.root.destroy).pack(pady=10)

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def iniciar_jogo(self):
        self.clear_screen()
        self.setup_ui()
        self.setup_mesa()
        self.animar()

    def setup_ui(self):
        self.top_bar = tk.Frame(self.root, bg="#1a1a1a", height=110, bd=0, highlightthickness=1, highlightbackground="#333")
        self.top_bar.pack(side=tk.TOP, fill=tk.X)
        self.top_bar.pack_propagate(False)
        
        self.info_frame = tk.Frame(self.top_bar, bg="#1a1a1a")
        self.info_frame.pack(side=tk.LEFT, padx=20)
        self.lbl_turno = tk.Label(self.info_frame, text="VEZ DO JOGADOR 1", bg="#1a1a1a", fg="#2ecc71", font=("Helvetica", 14, "bold"))
        self.lbl_turno.pack(anchor="w")
        self.lbl_grupo = tk.Label(self.info_frame, text="GRUPO: ABERTO", bg="#1a1a1a", fg="#bdc3c7", font=("Helvetica", 9, "bold"))
        self.lbl_grupo.pack(anchor="w")
        
        # Painel de Velocidades
        self.vel_frame = tk.Frame(self.top_bar, bg="#1a1a1a", padx=10)
        self.vel_frame.pack(side=tk.LEFT, padx=10, fill=tk.Y, pady=5)
        tk.Label(self.vel_frame, text="VELOCIDADES (px/s)", bg="#1a1a1a", fg="#FFD700", font=("Helvetica", 8, "bold")).pack()
        self.lbl_vel_branca = tk.Label(self.vel_frame, text="Taco (Branca): 0.00", bg="#1a1a1a", fg="white", font=("Courier", 10, "bold"))
        self.lbl_vel_branca.pack(anchor="w")
        self.lbl_vel_atingida = tk.Label(self.vel_frame, text="Impacto (Alvo): 0.00", bg="#1a1a1a", fg="white", font=("Courier", 10, "bold"))
        self.lbl_vel_atingida.pack(anchor="w")

        # Controles de Física
        physics_ctrl = tk.Frame(self.top_bar, bg="#1a1a1a")
        physics_ctrl.pack(side=tk.LEFT, padx=10)
        
        restituicao_frame = tk.LabelFrame(physics_ctrl, text="Restituição (e)", bg="#1a1a1a", fg="white", font=("Helvetica", 8, "bold"))
        restituicao_frame.pack(side=tk.LEFT, padx=5, pady=5)
        tk.Scale(restituicao_frame, from_=0.0, to=1.0, resolution=0.01, orient=tk.HORIZONTAL, variable=self.coef_restituicao, bg="#1a1a1a", fg="white", highlightthickness=0, length=80).pack()

        atrito_frame = tk.LabelFrame(physics_ctrl, text="Atrito", bg="#1a1a1a", fg="white", font=("Helvetica", 8, "bold"))
        atrito_frame.pack(side=tk.LEFT, padx=5, pady=5)
        tk.Scale(atrito_frame, from_=50, to=500, resolution=10, orient=tk.HORIZONTAL, variable=self.coef_atrito, bg="#1a1a1a", fg="white", highlightthickness=0, length=80).pack()

        self.lbl_instrucao = tk.Label(self.top_bar, text="Arraste na branca para tacar", bg="#1a1a1a", fg="#f1c40f", font=("Helvetica", 9, "italic"))
        self.lbl_instrucao.pack(side=tk.LEFT, padx=10)
        
        btn_frame = tk.Frame(self.top_bar, bg="#1a1a1a")
        btn_frame.pack(side=tk.RIGHT, padx=20)
        self.side_menu_visible = tk.BooleanVar(value=False)
        self.btn_toggle = tk.Button(btn_frame, text="MASSAS", bg="#3498db", fg="white", font=("Helvetica", 9, "bold"), bd=0, padx=10, pady=5, command=self.toggle_side_menu)
        self.btn_toggle.pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="REINICIAR", bg="#34495e", fg="white", font=("Helvetica", 9, "bold"), bd=0, padx=10, pady=5, command=self.reiniciar).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="MENU", bg="#e67e22", fg="white", font=("Helvetica", 9, "bold"), bd=0, padx=10, pady=5, command=self.mostrar_tela_inicial).pack(side=tk.LEFT, padx=5)

        self.main_container = tk.Frame(self.root, bg="#0f0f0f")
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        self.side_menu = tk.Frame(self.main_container, bg="#1a1a1a", width=250, bd=0, highlightthickness=1, highlightbackground="#333")
        tk.Label(self.side_menu, text="MASSA DAS BOLAS", bg="#1a1a1a", fg="#FFD700", font=("Helvetica", 11, "bold")).pack(pady=10)
        self.canvas_massas = tk.Canvas(self.side_menu, bg="#1a1a1a", highlightthickness=0, width=230)
        self.scrollbar = ttk.Scrollbar(self.side_menu, orient="vertical", command=self.canvas_massas.yview)
        self.scrollable_frame = tk.Frame(self.canvas_massas, bg="#1a1a1a")
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas_massas.configure(scrollregion=self.canvas_massas.bbox("all")))
        self.canvas_massas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas_massas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas_massas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        self.canvas = tk.Canvas(self.main_container, bg="#0f0f0f", highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.root.bind("<KeyPress>", self.mover_branca_teclado)

    def toggle_side_menu(self):
        if self.side_menu_visible.get():
            self.side_menu.pack_forget()
            self.btn_toggle.config(text="ABRIR MASSAS", bg="#3498db")
            self.side_menu_visible.set(False)
        else:
            self.side_menu.pack(side=tk.RIGHT, fill=tk.Y)
            self.btn_toggle.config(text="FECHAR MASSAS", bg="#e91e63")
            self.side_menu_visible.set(True)

    def criar_slider_massa(self, parent, nome_bola):
        var = tk.DoubleVar(value=1.0)
        f = tk.Frame(parent, bg="#1a1a1a", pady=2)
        f.pack(fill=tk.X, padx=5)
        tk.Label(f, text=nome_bola, bg="#1a1a1a", fg="#bdc3c7", font=("Helvetica", 8)).pack(side=tk.LEFT)
        tk.Scale(f, from_=0.1, to=5.0, resolution=0.1, orient=tk.HORIZONTAL, variable=var, bg="#1a1a1a", fg="white", highlightthickness=0, length=100, showvalue=False).pack(side=tk.RIGHT)
        val_lbl = tk.Label(f, text="1.0", bg="#1a1a1a", fg="#2ecc71", font=("Helvetica", 8, "bold"), width=3)
        val_lbl.pack(side=tk.RIGHT)
        var.trace_add("write", lambda *args: val_lbl.config(text=f"{var.get():.1f}"))
        return var

    def setup_mesa(self):
        # Desenhar bordas e feltro
        self.canvas.create_rectangle(self.margin_x-self.espessura_moldura, self.margin_y-self.espessura_moldura, self.margin_x+self.mesa_w+self.espessura_moldura, self.margin_y+self.mesa_h+self.espessura_moldura, fill="#3e2723", outline="#2b1b17", width=4)
        self.canvas.create_rectangle(self.margin_x, self.margin_y, self.margin_x+self.mesa_w, self.margin_y+self.mesa_h, fill="#0a5c36", outline="#074428", width=2)
        
        # Marcações
        lx_rel = self.mesa_w * 0.25
        self.canvas.create_line(self.margin_x+lx_rel, self.margin_y, self.margin_x+lx_rel, self.margin_y+self.mesa_h, fill="#1e7a50", width=2)
        self.canvas.create_arc(self.margin_x+lx_rel-60, self.margin_y+self.mesa_h/2-60, self.margin_x+lx_rel+60, self.margin_y+self.mesa_h/2+60, start=90, extent=-180, outline="#1e7a50", style=tk.ARC, width=2)
        
        # Caçapas
        self.buracos_pos = [
            (self.margin_x, self.margin_y), 
            (self.margin_x+self.mesa_w/2, self.margin_y), 
            (self.margin_x+self.mesa_w, self.margin_y), 
            (self.margin_x, self.margin_y+self.mesa_h), 
            (self.margin_x+self.mesa_w/2, self.margin_y+self.mesa_h), 
            (self.margin_x+self.mesa_w, self.margin_y+self.mesa_h)
        ]
        for bx, by in self.buracos_pos: 
            self.canvas.create_oval(bx-self.buraco_r, by-self.buraco_r, bx+self.buraco_r, by+self.buraco_r, fill="#000000", outline="#1a1a1a", width=2)
        
        self.setup_bolas()

    def setup_bolas(self):
        self.bolas = []; self.mass_vars = {}; bola_r = 11
        cores_info = {
            'solida': [('#f1c40f', 'Amarela'), ('#2980b9', 'Azul'), ('#e74c3c', 'Vermelha'), ('#8e44ad', 'Roxa'), ('#e67e22', 'Laranja'), ('#27ae60', 'Verde'), ('#c0392b', 'Bordô')], 
            'listrada': [('#f1c40f', 'Amarela'), ('#2980b9', 'Azul'), ('#e74c3c', 'Vermelha'), ('#8e44ad', 'Roxa'), ('#e67e22', 'Laranja'), ('#27ae60', 'Verde'), ('#c0392b', 'Bordô')], 
            'bola_8': ('#2c3e50', 'Preta'), 
            'bola_branca': ('#ecf0f1', 'Branca')
        }
        
        tri_x = self.margin_x + self.mesa_w * 0.70; centro_y = self.margin_y + self.mesa_h/2; off_x = (2*bola_r) * math.sqrt(3)/2
        ordem = [('solida', 0), ('listrada', 0), ('solida', 1), ('solida', 2), ('bola_8', -1), ('listrada', 1), ('listrada', 6), ('solida', 3), ('listrada', 2), ('solida', 4), ('listrada', 3), ('solida', 5), ('listrada', 4), ('listrada', 5), ('solida', 6)]
        
        idx = 0
        for l in range(5):
            y_s = centro_y - (l * (2*bola_r) / 2)
            for c in range(l + 1):
                tipo, c_idx = ordem[idx]
                if tipo == 'bola_8': 
                    cor, c_nome, nome = cores_info['bola_8'][0], cores_info['bola_8'][1], "Preta (8)"
                else: 
                    cor, c_nome = cores_info[tipo][c_idx]
                    nome = f"{c_nome} {'Lisa' if tipo=='solida' else 'Listrada'}"
                b = Bola(self.canvas, tri_x + l*off_x, y_s + c*(2*bola_r), bola_r, cor, tipo, nome)
                self.bolas.append(b)
                self.mass_vars[b] = self.criar_slider_massa(self.scrollable_frame, nome)
                idx += 1
        
        self.branca = Bola(self.canvas, self.margin_x + self.mesa_w * 0.25, centro_y, bola_r, cores_info['bola_branca'][0], 'bola_branca', "Branca")
        self.bolas.append(self.branca)
        self.mass_vars[self.branca] = self.criar_slider_massa(self.scrollable_frame, "Branca")

    def processar_fim_de_turno(self):
        self.movendo = False; p = self.jogador_atual; outro_p = 2 if p == 1 else 1; falta = False; msg_falta = ""
        
        if self.primeira_bola_atingida is None: 
            falta, msg_falta = True, "Falta: Nenhuma bola atingida!"
        elif self.grupos_definidos:
            meu_grupo = self.grupos[p]
            if self.primeira_bola_atingida.tipo != meu_grupo:
                restantes = [b for b in self.bolas if b.ativa and b.tipo == meu_grupo]
                if not (len(restantes) == 0 and self.primeira_bola_atingida.tipo == 'bola_8'): 
                    falta, msg_falta = True, f"Falta: Atingiu primeiro uma bola que não é {meu_grupo}!"
        
        if any(b.tipo == 'bola_branca' for b in self.bolas_encacapadas_nesta_jogada):
            falta, msg_falta = True, "Falta: Encaçapou a bola branca!"
            self.branca.x, self.branca.y, self.branca.vx, self.branca.vy = self.margin_x + self.mesa_w * 0.25, self.margin_y + self.mesa_h/2, 0, 0
            self.branca.ativa = True; self.branca.desenhar()
        
        if any(b.tipo == 'bola_8' for b in self.bolas_encacapadas_nesta_jogada):
            restantes = [b for b in self.bolas if b.ativa and b.tipo == self.grupos[p]] if self.grupos_definidos else [1]
            if falta or (self.grupos_definidos and len(restantes) > 0) or not self.grupos_definidos:
                self.vencedor = outro_p; messagebox.showinfo("Fim de Jogo", f"Jogador {p} perdeu a bola 8!")
            else: 
                self.vencedor = p; messagebox.showinfo("Fim de Jogo", f"Jogador {p} VENCEU!")
            self.mostrar_tela_inicial(); return
            
        bolas_validas = [b for b in self.bolas_encacapadas_nesta_jogada if b.tipo in ['solida', 'listrada']]
        if not falta and not self.grupos_definidos and len(bolas_validas) > 0:
            tipo = bolas_validas[0].tipo; self.grupos[p] = tipo; self.grupos[outro_p] = 'listrada' if tipo == 'solida' else 'solida'
            self.grupos_definidos = True; self.lbl_grupo.config(text=f"P1: {self.grupos[1].upper()} | P2: {self.grupos[2].upper()}")
        
        if not (not falta and len(bolas_validas) > 0 and (not self.grupos_definidos or any(b.tipo == self.grupos[p] for b in bolas_validas))):
            self.jogador_atual = outro_p; self.lbl_turno.config(text=f"VEZ DO JOGADOR {self.jogador_atual}", fg="#2ecc71" if self.jogador_atual == 1 else "#3498db")
        
        if falta: 
            self.bola_na_mao = True; self.lbl_instrucao.config(text="BOLA NA MÃO!"); messagebox.showwarning("Falta", msg_falta)

    def animar(self):
        if self.vencedor: return
        bolas_paradas = True; e_atual = self.coef_restituicao.get(); atrito_atual = self.coef_atrito.get(); dt = 0.016
        
        # Sincronizar massas
        for b in self.bolas:
            if b in self.mass_vars: b.massa = self.mass_vars[b].get()
        
        # Física de Sub-passos (Substepping) para maior precisão
        sub_steps = 4
        sub_dt = dt / sub_steps
        
        for _ in range(sub_steps):
            for i, b1 in enumerate(self.bolas):
                if not b1.ativa: continue
                
                # Só verificamos se parou no passo principal, mas aqui atualizamos
                if abs(b1.vx) > 1.0 or abs(b1.vy) > 1.0: bolas_paradas = False
                
                b1.aplicar_atrito(sub_dt, desaceleracao_linear=atrito_atual)
                resolver_colisao_paredes(b1, self.margin_x, self.margin_y, self.margin_x + self.mesa_w, self.margin_y + self.mesa_h)
                
                for j in range(i+1, len(self.bolas)):
                    b2 = self.bolas[j]
                    if resolver_colisao_bolas(b1, b2, e=e_atual):
                        # Registro de impacto para UI
                        if (b1.tipo == 'bola_branca' or b2.tipo == 'bola_branca') and not self.ja_registrou_impacto:
                            alvo = b2 if b1.tipo == 'bola_branca' else b1
                            self.primeira_bola_atingida = alvo
                            self.vel_alvo_impacto = math.sqrt(alvo.vx**2 + alvo.vy**2)
                            self.lbl_vel_atingida.config(text=f"Impacto (Alvo): {self.vel_alvo_impacto:.2f}", fg="#e74c3c")
                            self.ja_registrou_impacto = True
                
                b1.atualizar_posicao(sub_dt)
                
                # Verificar caçapas
                for bx, by in self.buracos_pos:
                    if (b1.x - bx)**2 + (b1.y - by)**2 <= (self.buraco_r + 2)**2: 
                        self.bolas_encacapadas_nesta_jogada.append(b1)
                        b1.remover()
                        break

        if self.movendo and bolas_paradas: 
            self.processar_fim_de_turno()
        
        self.root.after(16, self.animar)

    def on_click(self, e):
        if not self.movendo and not self.vencedor and not self.bola_na_mao:
            if (e.x - self.branca.x)**2 + (e.y - self.branca.y)**2 <= (self.branca.raio*3)**2: 
                self.selecionada = True

    def on_drag(self, e):
        if self.selecionada:
            if self.mira_id: self.canvas.delete(self.mira_id)
            if self.trajetoria_id: self.canvas.delete(self.trajetoria_id)
            
            # Desenhar linha do taco (atrás da branca)
            dx, dy = self.branca.x - e.x, self.branca.y - e.y
            dist = math.sqrt(dx**2 + dy**2)
            if dist > 5:
                # Linha de força
                self.mira_id = self.canvas.create_line(self.branca.x, self.branca.y, e.x, e.y, fill='#ecf0f1', width=3, dash=(5, 2))
                # Guia de trajetória
                nx, ny = dx/dist, dy/dist
                self.trajetoria_id = self.canvas.create_line(self.branca.x, self.branca.y, self.branca.x + nx * 150, self.branca.y + ny * 150, fill='#f1c40f', width=1, dash=(2, 2))

    def on_release(self, e):
        if self.selecionada:
            dx, dy = self.branca.x - e.x, self.branca.y - e.y
            forca = min(math.sqrt(dx**2 + dy**2) * 3.5, 800) 
            angulo = math.atan2(dy, dx)
            
            if forca > 10:
                self.vel_branca_saida = forca
                self.lbl_vel_branca.config(text=f"Taco (Branca): {self.vel_branca_saida:.2f}", fg="#2ecc71")
                self.lbl_vel_atingida.config(text="Impacto (Alvo): ...", fg="white")
                
                self.ja_registrou_impacto = False
                self.branca.vx = math.cos(angulo) * forca
                self.branca.vy = math.sin(angulo) * forca
                
                self.selecionada = False
                self.movendo = True
                self.bolas_encacapadas_nesta_jogada = []
                self.primeira_bola_atingida = None
            
            if self.mira_id: self.canvas.delete(self.mira_id); self.mira_id = None
            if self.trajetoria_id: self.canvas.delete(self.trajetoria_id); self.trajetoria_id = None

    def mover_branca_teclado(self, event):
        if not self.bola_na_mao or self.movendo: return
        passo = 5; nx, ny = self.branca.x, self.branca.y
        if event.keysym == 'Up': ny -= passo
        elif event.keysym == 'Down': ny += passo
        elif event.keysym == 'Left': nx -= passo
        elif event.keysym == 'Right': nx += passo
        elif event.keysym == 'Return': 
            self.bola_na_mao = False
            self.lbl_instrucao.config(text="Arraste na branca para tacar")
            return
            
        # Limites da mesa para reposicionamento
        if self.margin_x + 20 <= nx <= self.margin_x + self.mesa_w - 20: self.branca.x = nx
        if self.margin_y + 20 <= ny <= self.margin_y + self.mesa_h - 20: self.branca.y = ny
        self.branca.atualizar_posicao(0)

    def reiniciar(self):
        self.vencedor = None; self.jogador_atual = 1; self.grupos_definidos = False; self.grupos = {1: None, 2: None}; self.iniciar_jogo()

if __name__ == "__main__":
    root = tk.Tk()
    app = BilharApp(root)
    root.mainloop()
